<?php
// header("Content-Type: text-html; charset=utf-8");

session_start();

if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('connect.php');
$conn = OpenCon();

$stu_id=$_POST['stu_id'];
$stu_password=$_POST['stu_password'];


if($stu_id && $stu_password){
    $checkstu = "SELECT * FROM student WHERE stu_id='$stu_id' and stu_password='$stu_password'";
    $result = mysqli_query($conn, $checkstu);
    $rows=mysqli_num_rows($result);
    if($rows){
        header("refresh:0; url= demo.php");
        $_SESSION["stu_id"]=$stu_id;                          //store the id of student log in 

        $findname=" select * from student where stu_id='$stu_id'";
        $nameresult = mysqli_query ($conn, $findname);
        while ($rowstuname =mysqli_fetch_array($nameresult))
        {
            $_SESSION["stu_name"] = $rowstuname['stu_name'];    //store the name of student log in 
           
        }                                                   
      
        //$_SESSION["avg_score"]='0';
       // $findcore=" select * from review where stu_id='$stu_id'";
        //$scoreresult = mysqli_query ($conn, $findcore);
       // while ($rowscore = mysqli_fetch_assoc ($scoreresult))
       // {
       //     if($rowscore["grade_level"])
       //     {
       //     $_SESSION["avg_score"]=$rowscore["grade_level"];  ////store the average score of student log in 
        //    }
            
      //  }


       
        exit;
    }

    else{
        echo "Wrong student ID or Password";
        echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/student-login.html';},1500);
        </script>
        ";
    }
}
else{
    echo "Please complete your student ID and password";
    echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/student-login.html';},1500);
        </script>
        ";

}


mysqli_close($conn);


?>