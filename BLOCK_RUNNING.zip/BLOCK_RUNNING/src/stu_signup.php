<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('connect.php');
$conn = OpenCon();

$stu_id = $_POST['stu_id'];
$stu_name = $_POST['stu_name'];
$stu_password = $_POST['stu_password'];
$stu_add =$_POST['address'];
$stu_tel = $_POST['tel'];
$stu_email = $_POST['email'];


$exist="select stu_id from student where stu_id='$stu_id'";
$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
    $qu = "INSERT INTO student VALUES ('$stu_id', '$stu_name','$stu_password','$stu_add', '$stu_tel', '$stu_email')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        die ('Error: ' . mysqli_error());
        echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/student-login.html';},1500);
       whi </script>
        ";
    
    }
    else{
        echo "Sign up successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='/it_project/student-login.html';},1500);
            </script>
            ";
    
    
    }
   
}
else
{

    echo "Your ID has been signed up, you'd better change another ID";
    echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/student-login.html';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>