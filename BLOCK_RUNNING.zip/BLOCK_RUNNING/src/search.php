<?php
session_start();
include ('connect.php');
$conn = OpenCon();
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search for Feedback</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/it_project/styles.css">

</head>
<body>

<div>
    <p class="p12">SEARCH FOR FEEDBACK</p>
    <div class="div10">
        <table class="table2">
            <tr><!-- form action="" -->
            <form name="search" method="post" action=" " >
                <td class="td2">StudentID:</td>
                <td class="td3"><input type="text" name="stu_id" class="input1"></td>
                <td class="td4"><input type="submit" value="Submit" class="submit1" name="submit"></td>
            </form>
            </tr>  
        </table>
    </div>




    <div class="div11">
        <fieldset>
            <legend class="legend1">FEEDBACK</legend>
            <!-- feedback p -->
            <?php


            if($_POST["stu_id"])
               {
              $stu_id=$_POST["stu_id"];
                }


            if ($stu_id)
                {       
                    $sqlname="select stu_name from student where stu_id='$stu_id'";
                    $resultname = mysqli_query($conn, $sqlname);
                    while ($rowname = mysqli_fetch_array($resultname))
                        {
                            $stu_name=$rowname['stu_name'];
                        }
    // output the name of student 
                }
                

            if ($stu_id)
            {
                $sqlfb="select tea_feedback from feedback, review  where review.stu_id='$stu_id' and review.grade_level= feedback.grade_level ";
                $resultfb = mysqli_query($conn, $sqlfb);
                while ($rowfb = mysqli_fetch_array($resultfb))
                {
                    $tea_fb=$rowfb['tea_feedback'];
                }
                // output the related feedback of student to teacher
            }
            echo "<p style='font-size:20px'>Student: $stu_name</p>";
            echo "<p style='font-size:20px'>$tea_fb</p>"

            ?>

        </fieldset>
    </div>





    <div class="div11">
        <fieldset>
            <legend class="legend1">GAME RECORD</legend>
            <!-- game record table -->
            
            <table>
                <tr>
                <th style="font-size:25px">Game Level</th>
                <th style="font-size:25px">Score</th>
                </tr>
            <?php
            $sqlrecord="select * from play where stu_id='$stu_id'";
            $resultrecord = mysqli_query($conn, $sqlrecord);
        
            while ($rowrecord = mysqli_fetch_array($resultrecord))
            {
                 
            ?>

            <tr>
            <td style="font-size:20px"><?php echo $rowrecord["game_level"] ?></td>
            <td style="font-size:20px"><?php echo $rowrecord["score"] ?> </td>
            
            </tr>
            <?php
                }
            ?>
        </fieldset>
    </div>
    
</div>



<?php
mysqli_close($conn);
?>
<div class="footer">
<div class="div5" style="top:0"><a href="teacher-overall.php"><button type="button" class="button7">BACK</button></a></div>
</div>
</body>
</html>