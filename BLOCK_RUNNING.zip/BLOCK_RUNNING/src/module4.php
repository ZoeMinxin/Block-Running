
<?php
session_start();
$name = $_SESSION["stu_name"];
$stu_id=$_SESSION["stu_id"];
include ('connect.php');
$conn = OpenCon();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Module4</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="/it_project/styles.css">

</head>
<body>

<nav class="navbar-inverse nav1">
  <div class="container-fluid">
    <div class="navbar-header">
     
    <?php
     // getting the score of each student 
     $avgscore='0';
     $findcore=" select * from review where stu_id='$stu_id'";
     $scoreresult = mysqli_query ($conn, $findcore);
     while ($rowscore = mysqli_fetch_assoc ($scoreresult))
     {
         if($rowscore["grade_level"])
         {
           $avgscore =$rowscore["grade_level"];  ////store the average score of student log in 
         }
         
     }
      echo "<p style='font-size:2em;text-align:center; padding: 20px 15px'>Hi $name, your total average score is $avgscore</p>";
      ?>

    </div>
   <!-- get student feedback from database -->
   <?php
  
    $sqlsfb="select stu_feedback from feedback where grade_level='$avgscore'";
    $resultsfb = mysqli_query ($conn, $sqlsfb);
    while ($rowsfb = mysqli_fetch_array ($resultsfb))
    {
      $sfb=$rowsfb['stu_feedback'];
    }
    ?>

    <ul class="nav navbar-nav navbar-right">  
      
      <li><a href="rank.php"><button type="button" class="button1 button12">RANK</button></a></li>
      <li><a href="#"><button type="button" class="button1 button13" id="myFeedbackBtn">FEEDBACK</button></a></li>
<!-- feedback js -->
      <div id="myFeedbackModal" class="modal">
          <div class="modal-content">
            <span class="feedback_close">&times;</span>
            <?php echo "<p style='font-size:2em' >$sfb</p> "; ?>    <!-- FEEDBACK from database -->      
          </div>
        </div>
        <script>
          var feedback_modal = document.getElementById('myFeedbackModal');
    
          var feedback_btn = document.getElementById("myFeedbackBtn");
    
          var feedback_span = document.getElementsByClassName("feedback_close")[0];
    
          feedback_btn.onclick = function() {
            feedback_modal.style.display = "block";
          }
    
          feedback_span.onclick = function() {
            feedback_modal.style.display = "none";
          }
        </script>

    </ul>
  </div>
</nav>
  
<div class="container">
  <p class="p p3">MODULE 4</p><br/>
  <p class="p p4">COMPREHENSIVE</p><br/>
  <table>
    <tr>
        <th><a href="module4-1.php"><button type="button" class="button4">1</button></a></th>
        <th><a href="module4-2.php"><button type="button" class="button4">2</button></a></th>
        <th><a href="module4-3.php"><button type="button" class="button4">3</button></a></th>
        <th><a href="module4-4.php"><button type="button" class="button4">4</button></a></th>
        <th><a href="module4-5.php"><button type="button" class="button4">5</button></a></th>
    </tr>
    <tr>
        <th><a href="module4-6.php"><button type="button" class="button4">6</button></a></th>
        <th><a href="module4-7.php"><button type="button" class="button4">7</button></a></th>
        <th><a href="module4-8.php"><button type="button" class="button4">8</button></a></th>
        <th><a href="module4-9.php"><button type="button" class="button4">9</button></a></th>
        <th><a href="module4-10.php"><button type="button" class="button4">10</button></a></th>
    </tr>
  </table>
  <div class="div5"><a href="demo.php"><button type="button" class="button3">BACK</button></a></div>
</div>

</body>
</html>