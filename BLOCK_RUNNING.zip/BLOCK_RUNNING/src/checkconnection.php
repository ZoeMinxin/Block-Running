
<html>
<body>

<?php 
include 'connect.php';
$conn = OpenCon();
echo "<p>Connected Successfully<p>";
CloseCon($conn);
?>
   


</body>
</html>
