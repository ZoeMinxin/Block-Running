<?php
session_start();
$name = $_SESSION["stu_name"];
//$avgscore = $_SESSION["avg_score"];
$stu_id=$_SESSION["stu_id"];
$gamelevel ="1-1";
include ('connect.php');
$conn = OpenCon();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Module1-1</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
  <link rel="stylesheet" href="/it_project/styles.css">
</head>
<body>

<nav class="navbar-inverse nav1">
  <div class="container-fluid">
    <div class="navbar-header">

    <?php
     // getting the score of each student 
     $avgscore='0';
     $findcore=" select * from review where stu_id='$stu_id'";
     $scoreresult = mysqli_query ($conn, $findcore);
     while ($rowscore = mysqli_fetch_assoc ($scoreresult))
     {
         if($rowscore["grade_level"])
         {
           $avgscore =$rowscore["grade_level"];  ////store the average score of student log in 
         }
         
     }
      echo "<p style='font-size:2em;text-align:center; padding: 20px 15px'>Hi $name, your total average score is $avgscore</p>";
    ?>

    </div>

    <!-- get student feedback from database -->
    <?php
   
    $sqlsfb="select stu_feedback from feedback where grade_level='$avgscore'";
    $resultsfb = mysqli_query ($conn, $sqlsfb);
    while ($rowsfb = mysqli_fetch_array ($resultsfb))
    {
      $sfb=$rowsfb['stu_feedback'];
    }
    ?>

    <ul class="nav navbar-nav navbar-right">  
      
      <li><a href="rank.php"><button type="button" class="button1 button12">RANK</button></a></li>
      <li><a href="#"><button type="button" class="button1 button13" id="myFeedbackBtn">FEEDBACK</button></a></li>
<!-- feedback js -->
      <div id="myFeedbackModal" class="modal">
          <div class="modal-content">
            <span class="feedback_close">&times;</span>
            <?php echo "<p style='font-size:2em' >$sfb</p> "; ?>    <!-- FEEDBACK from database -->      
          </div>
        </div>
        <script>
          var feedback_modal = document.getElementById('myFeedbackModal');
    
          var feedback_btn = document.getElementById("myFeedbackBtn");
    
          var feedback_span = document.getElementsByClassName("feedback_close")[0];
    
          feedback_btn.onclick = function() {
            feedback_modal.style.display = "block";
          }
    
          feedback_span.onclick = function() {
            feedback_modal.style.display = "none";
          }
        </script>

    </ul>
  </div>
</nav>
  
<div>
    <div class="div6">MODULE 1 - LEVEL 1</div>
    <div class="div7"><button type="button" class="button5" id="myHintBtn">HINT</button></div>

    <!-- hint modal start -->
    <div id="myHintModal" class="modal">
      <div class="modal-content">
        <span class="hint_close">&times;</span>
        <p style="font-size: 19px;"><b>ARE YOU SURE YOU WANT TO SEE THE HINT ?</b></p>
        <p style="font-size: 16px; color: red;">(IF SO, YOU CAN ONLY GET <b>0</b> IN THIS LEVEL)</p>
        <script type="text/javascript">
          
          function xx(){
            document.getElementById('bt').style.display="block";
          }
          
          function hint_yes(){
            $.ajax({
            url:'s1-1.php',
            type: 'POST',
            data: {avgScore:0},
            //success: function(data){console.log(data);alert("done");}
            });
            //localStorage.setItem('aaa',0);
            //return 0;// print hint yes ---> aaa=0
          }
        </script>
        <input class="button5" type="button" value="YES" onclick="xx();hint_yes();"/><!-- RETURN 0 IN SCORE -->
        <div id="bt" style="display:none">
          <img src="/it_project/image/hits_photo/1-1.jpg" width="100%" height="50%" >
          <p style="font-size: 20px; color: red; text-align:center">Sorry! You can not play this level again!</p>
          <input class="button5" type="button" value="NEXT LEVEL" onclick="window.open('module1-2.php')"/>
        </div>
      </div>
    </div>
    <script>
      var hint_modal = document.getElementById('myHintModal');

      var hint_btn = document.getElementById("myHintBtn");

      var hint_span = document.getElementsByClassName("hint_close")[0];

      hint_btn.onclick = function() {
        hint_modal.style.display = "block";
      }

      hint_span.onclick = function() {
        hint_modal.style.display = "none";
      }
      </script>
      <!-- hint modal end -->

    <div class="div7"><a href="module1-1.php"><button type="button" class="button9">RESTART</button></a></div>
</div>

<!-- game div start -->
<div class="block" > 
  <div class="group" id="a11"></div> 
  <div class="group" id="a12"></div> 
  <div class="group" id="a13"></div> 
  <div class="group" id="a14"></div> 
  <div class="group" id="a15"></div> 
  <div class="group" id="a16"></div> 
  <!--first row-->
  <div class="group" id="a21"></div>
  <div class="group" id="a22"></div>
  <div class="group" id="a23"></div> 
  <div class="group" id="a24"></div> 
  <div class="group" id="a25"></div> 
  <div class="group" id="a26"></div>
   <!--second row-->      
  <div class="group " id="a31"></div> 
  <div class="group beginpoint" id="a32" onclick="clickfun(this)"></div> 
  <div class="group imagepoint" id="a33" onclick="clickfun(this)"></div> 
  <div class="group imagepoint" id="a34" onclick="clickfun(this)"></div> 
  <div class="group" id="a35"></div> 
  <div class="group" id="a36"></div> 
  <!--third row-->       
  <div class="group" id="a41"></div> 
  <div class="group" id="a42"></div> 
  <div class="group" id="a43"></div> 
  <div class="group" id="a44"></div> 
  <div class="group" id="a45"></div> 
  <div class="group" id="a46"></div>
   <!--forth row-->      
  <div class="group" id="a51"></div> 
  <div class="group" id="a52"></div> 
  <div class="group" id="a53"></div> 
  <div class="group" id="a54"></div> 
  <div class="group" id="a55"></div> 
  <div class="group" id="a56"></div>
  <!--fifth row-->     
  <div class="group" id="a61"></div> 
  <div class="group" id="a62"></div> 
  <div class="group" id="a63"></div> 
  <div class="group" id="a64"></div> 
  <div class="group" id="a65"></div> 
  <div class="group" id="a66"></div>
  <!--sixth row--> 
           
</div> 
<!-- game div end -->
      
<!-- game js start -->    
  <script type="text/javascript" defer="defer">
  
      var useranswer=["a","a","a"]; //clicked id of users
      var rightaswer=["a32","a33","a34"]; //the right answer of this level 
      var loadcolor=["#0B2161","#08298A","#0431B4","#013ADF","#0040FF","#2E64FE","#5882FA","#819FF7","#A9BCF5","#CED8F6","#E0E6F8","#F8E0EC","#F6CEEC","#F5A9E1","#F781D8","#FA58D0","#FE2EC8","#FF00BF"]
    
      
    
      
      var isclick = false;
      var count=0; //count the times of clicking 
      
      
      
      function isInArray(arr,value){
      for(var i = 0; i < arr.length; i++){
          if(value === arr[i]){
              return true;
          }
      }
      return false;
          }   //make sure no repeat block is clicked 
  </script>
<!-- game js end --> 

  <div class="div5"><a href="module1.php"><button type="button" class="button3">BACK</button></a></div>

  <div class="div19"><button id="myBtn" class="button10" >CHECK</button></div>

<!-- the modal start -->
<div id="myModal" class="modal">

  <div class="modal-content">
    <span class="close">&times;</span>

    <p id="demo" style="font-size: 25px; text-align: center;">
      <script>

var m=false;
var str1="SORRY! \n THE ANSWER IS WRONG... \n PLEASE TRY AGAIN!"; //false
var str2="CONGRATULATION! \n YOU PASSED THIS LEVEL! \n AWESOME!"; //pass

while(str1.indexOf("\\n")>=0){
  var str0=str1.replace("\\n","\n");
}
while(str2.indexOf("\\n")>=0){
  var str0=str2.replace("\\n","\n");
}

// check the answer
        function clickfun(_this){
         
          isclick=true;
          if(isInArray(useranswer,_this.id)==false){
          
              count+=1;
              useranswer[count-1]=_this.id;
              _this.style.backgroundColor=loadcolor[count-1];
              console.log(count+"and"+useranswer[count-1]);
              
              if(count>=3){
              console.log(useranswer);
               
               if (useranswer.toString()===rightaswer.toString()){
                  console.log("pass!");
                  m=true;
               }
              else {
                  console.log("sorry!");
                  m=false;
                }
                  }
              }
          }
        function checkm(){
        
          if(m){
            return str2;
          }
          else{
            return str1;
          }
        }
      </script>
    </p>

    <div style="font-size:20px; text-align:center">
      <p style="display: inline">You have tried </p>  
      <p id="box" style="display: inline">1</p>
      <p style="display: inline"> times!</p>
    </div>

    <input class="button5" type="button" value="NEXT LEVEL" onclick="window.open('module1-2.php')">
    <input class="button5" type="button" value="TRY AGAIN" onclick="tryAgain()">

    <script language="javascript">
        function tryAgain(){
          window.location.href='module1-1.php';
        }
    </script>

  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');
    
    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");
    
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];
    
    // When the user clicks the button, open the modal 
    btn.onclick = function() {
      //window.location.href="module1-1.php?score="+aaa;
      modal.style.display = "block";
      document.getElementById("demo").innerText=checkm();
      $.ajax({
        url:'s1-1.php',
        type: 'POST',
        data: {avgScore:aaa},
        //success: function(data){console.log(data);alert("done");}
      });
    }
    
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
    
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
    </script>
<!-- the modal end -->

<script type="text/javascript" src="test.js"></script>

<?php
mysqli_close($conn);
?>

</body>

</html>