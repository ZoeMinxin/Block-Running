// refresh one time count +1
var aa=document.getElementById("box");

window.onload=function()
{
    if (window.name==""){
        window.name="1";
    }else{
        window.name=eval(window.name)+1;
        aa.innerHTML=window.name;
    }
}

// aa ---> aaa(level_score)

//console.log(window.name);
var aap=parseInt(window.name);
//console.log(aap);
var aaa;
if(aaa!=="0"){
switch(aap){
    case 1: aaa=10; break;
    case 2: aaa=8; break;
    case 3: aaa=6; break;
    case 4: aaa=4; break;
    case 5: aaa=2; break;
    case 6: aaa=2; break;
    case 7: aaa=2; break;
    case 8: aaa=2; break;
    case 9: aaa=2; break;
    case 10: aaa=1; break;
    case 11: aaa=1; break;
    case 12: aaa=1; break;
    case 13: aaa=1; break;
    case 14: aaa=1; break;
    case 15: aaa=1; break;
    case 16: aaa=1; break;
    case 17: aaa=1; break;
    case 18: aaa=1; break;
    case 19: aaa=1; break;
    case 20: aaa=1; break;
    case 21: aaa=1; break;
    case 22: aaa=1; break;
    case 23: aaa=1; break;
    case 24: aaa=1; break;
    case 25: aaa=1; break;
    case 26: aaa=1; break;
    case 27: aaa=1; break;
    case 28: aaa=1; break;
    case 29: aaa=1; break;
    case 30: aaa=1; break;
    case 31: aaa=1; break;
    case 32: aaa=1; break;
    case 33: aaa=1; break;
    case 34: aaa=1; break;
    case 35: aaa=1; break;
    case 36: aaa=1; break;
    case 37: aaa=1; break;
    case 38: aaa=1; break;
    case 39: aaa=1; break;
    case 40: aaa=1; break;
    case 41: aaa=1; break;
    case 42: aaa=1; break;
    case 43: aaa=1; break;
    case 44: aaa=1; break;
    case 45: aaa=1; break;
    case 46: aaa=1; break;
    case 47: aaa=1; break;
    case 48: aaa=1; break;
    case 49: aaa=1; break;
    case 50: aaa=1; break;
    default: aaa=12;
}}
