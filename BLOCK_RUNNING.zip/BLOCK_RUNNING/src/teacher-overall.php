<?php
session_start();
$tname=$_SESSION["tea_name"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
  <link rel="stylesheet" href="/it_project/styles.css">

</head>
<body>
<nav class="navbar-inverse nav1">
  <div class="container-fluid">
    <div class="navbar-header">
      <?php
      echo "<p style='font-size:2em; padding: 20px 15px'>Hi,$tname </p>";
      ?>
    </div>



<ul class="nav navbar-nav navbar-right">  
      
<li><a href="/it_project/teacher-login.html"><button type="button" class="button1 button14">LOGOUT</button></a></li>
</ul>
</div>
</nav>
 
  
<div class="container">
    <p class="p p2">BLOCK RUNNING</p>
    <p class="p13">STUDENT RECORD</p>
    <ul class="ul1">
        <li><a href="/it_project/src/stuinfo.php"><button type="button" class="button6">STUDENT INFORMATION</button></a></li>
        <li><a href="/it_project/src/game-record.php"><button type="button" class="button6">GAME RECORD</button></a></li>
        <li><a href="/it_project/src/rank.php"><button type="button" class="button6">OVERALL RANK</button></a></li>

        <li><a href="/it_project/src/distribution.php"><button type="button" class="button6">DISTRIBUTION MAP</button></a></li>
        <li><a href="/it_project/src/search.php"><button type="button" class="button6">SEARCH</button></a></li>
    </ul>
</div>

</body>
</html>