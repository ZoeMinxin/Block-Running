<?php
// header("Content-Type: text-html; charset=utf-8");
session_start();

if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('connect.php');
$conn = OpenCon();

$tea_id=$_POST['tea_id'];
$tea_password=$_POST['tea_password'];


if($tea_id && $tea_password){
    $checktea = "SELECT * FROM teacher WHERE tea_id='$tea_id' and tea_password='$tea_password'";
    $result = mysqli_query($conn, $checktea);
    $rows=mysqli_num_rows($result);
    if($rows){
        header("refresh:0; url= /it_project/src/teacher-overall.php");
        $_SESSION["tea_id"]=$tea_id;              //store id of teacher log in 




        $findtname=" select * from teacher where tea_id='$tea_id'";
        $tnameresult = mysqli_query ($conn, $findtname);
        while ($rowtname =mysqli_fetch_array($tnameresult))
        {
            $_SESSION["tea_name"] = $rowtname['tea_name'];    //store the name of student log in 
           
        }  



        exit;
    }
    else{
        echo "Wrong teacher ID or Password";
        echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/teacher-login.html';},1500);
        </script>
        ";
    }
}
else{
    echo "Please complete your teacher ID and password";
    echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/teacher-login.html';},1500);
        </script>
        ";

}


mysqli_close($conn);


?>