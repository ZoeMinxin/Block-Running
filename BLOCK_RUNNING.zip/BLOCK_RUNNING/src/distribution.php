<?php

include ('connect.php');
$conn = OpenCon();

?>

<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <link rel="stylesheet" href="/it_project/styles.css">
    </head>


<body>
    <h1 style="text-align: center">Distribution Map of Student Score</h1>


    <?php
    //amount of students whose score is 0
    $qu0="select count(stu_id) as co, grade_level from review where grade_level =0";
    $re0=mysqli_query($conn, $qu0);
    while ($row0 =mysqli_fetch_array($re0))
    {
        $s0 = $row0['co'];    
    }

    //amount of students whose score is 1
    $qu1="select count(stu_id) as co, grade_level from review where grade_level =1";
    $re1=mysqli_query($conn, $qu1);
    while ($row1 =mysqli_fetch_array($re1))
    {
        $s1 = $row1['co'];    
    }

    //amount of students whose score is 2
    $qu2="select count(stu_id) as co, grade_level from review where grade_level =2";
    $re2=mysqli_query($conn, $qu2);
    while ($row2 =mysqli_fetch_array($re2))
    {
        $s2 = $row2['co'];    
    }

    //amount of students whose score is 3
    $qu3="select count(stu_id) as co, grade_level from review where grade_level =3";
    $re3=mysqli_query($conn, $qu3);
    while ($row3 =mysqli_fetch_array($re3))
    {
        $s3 = $row3['co'];    
    }

    //amount of students whose score is 4
    $qu4="select count(stu_id) as co, grade_level from review where grade_level =4";
    $re4=mysqli_query($conn, $qu4);
    while ($row4 =mysqli_fetch_array($re4))
    {
        $s4 = $row4['co'];    
    }

    //amount of students whose score is 5
    $qu5="select count(stu_id) as co, grade_level from review where grade_level =5";
    $re5=mysqli_query($conn, $qu5);
    while ($row5 =mysqli_fetch_array($re5))
    {
        $s5 = $row5['co'];    
    }

    //amount of students whose score is 6
    $qu6="select count(stu_id) as co, grade_level from review where grade_level =6";
    $re6=mysqli_query($conn, $qu6);
    while ($row6 =mysqli_fetch_array($re6))
    {
        $s6 = $row6['co'];    
    }

    //amount of students whose score is 7
    $qu7="select count(stu_id) as co, grade_level from review where grade_level =7";
    $re7=mysqli_query($conn, $qu7);
    while ($row7 =mysqli_fetch_array($re7))
    {
        $s7 = $row7['co'];    
    }

    //amount of students whose score is 8
    $qu8="select count(stu_id) as co, grade_level from review where grade_level =8";
    $re8=mysqli_query($conn, $qu8);
    while ($row8 =mysqli_fetch_array($re8))
    {
        $s8 = $row8['co'];    
    }

    //amount of students whose score is 9
    $qu9="select count(stu_id) as co, grade_level from review where grade_level =9";
    $re9=mysqli_query($conn, $qu9);
    while ($row9 =mysqli_fetch_array($re9))
    {
        $s9 = $row9['co'];    
    }

    //amount of students whose score is 10
    $qu10="select count(stu_id) as co, grade_level from review where grade_level =10";
    $re10=mysqli_query($conn, $qu10);
    while ($row10 =mysqli_fetch_array($re10))
    {
        $s10 = $row10['co'];    
    }

    //amount of students whose score is 11
    $qu11="select count(stu_id) as co, grade_level from review where grade_level =11";
    $re11=mysqli_query($conn, $qu11);
    while ($row11 =mysqli_fetch_array($re11))
    {
        $s11 = $row11['co'];    
    }
    //$s11= (int)$s11;
  
    //amount of students whose score is 12
    $qu12="select count(stu_id) as co, grade_level from review where grade_level =12";
    $re12=mysqli_query($conn, $qu12);
    while ($row12 =mysqli_fetch_array($re12))
    {
        $s12 = $row12['co'];    
    }

    ?>

    <div class="chart-container" style="position: relative; height: 38vh; width:85vw">
    <canvas id="myChart"></canvas>
    </div>

    <script>
    var s0 ="<?php echo $s0 ?>";
    var s1 ="<?php echo $s1 ?>";
    var s2 ="<?php echo $s2 ?>";
    var s3 ="<?php echo $s3 ?>";
    var s4 ="<?php echo $s4 ?>";
    var s5 ="<?php echo $s5 ?>";
    var s6 ="<?php echo $s6 ?>";
    var s7 ="<?php echo $s7 ?>";
    var s8 ="<?php echo $s8 ?>";
    var s9 ="<?php echo $s9 ?>";
    var s10 ="<?php echo $s10 ?>";
    var s11 ="<?php echo $s11 ?>";
    var s12 ="<?php echo $s12 ?>";
    var ctx = document.getElementById('myChart').getContext('2d');

    var chart = new Chart(ctx, {
    
    type: 'bar',

    // The data for  dataset
    data: {
        labels: ['score:0', 'score:1', 'score:2', 'score:3', 'score:4', 'score:5', 'score:6', 'score:7', 'score:8', 'score:9', 'score:10', 'score:11', 'score:12'],
        datasets: [{
            backgroundColor: 'rgb(105,105,105)',
            borderColor: 'black',
            data: [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]   //from database score=0/1/2/3/4/5/6/7/8/9/10/11/12
        }]
    },

    // Configuration options 
    options: {
        legend: {display: false,}
       
        }

});

function updateScales(chart){
    var xScale = chart.scales['x-axis-0'];
    var yScale = chart.scales['y-axis-0'];
    chart.options.scales = {
        xAxes: [{
            id: 'newId',
            display: true
        }],
        yAxes: [{
            display: true,
            //type: 'logarithmic'
            ticks:{
                minTickslimit:1
            }
        }]
    };
}
    
</script>

<div class="footer">
<div class="div5" style="top:0"><a href="teacher-overall.php"><button type="button" class="button7">BACK</button></a></div>
</div>


</body>

<?php
mysqli_close($conn);
?>


</html>