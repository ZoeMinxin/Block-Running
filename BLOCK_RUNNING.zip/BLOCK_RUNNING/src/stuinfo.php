<?php
session_start();
include ('connect.php');
$conn = OpenCon();


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="/it_project/styles.css">
<style>


h1 {
  text-align: center;
  padding: 50px;
  color: black;
  font: 400 100px/1.2 'Merienda One', Helvetica, sans-serif;
  background: -webkit-linear-gradient(left,red,orange,yellow,green,blue,purple);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

table {
  border-collapse: collapse;
  width: 80%;
  border-style:none;
}

td, th {
  border-style:none;
  text-align: left;
  height: 45px;
  padding: 0 0 0 20px;
  font-size: 120%;
  font-weight: bold;
  text-align: center;
}

th{
  background-color:#87CEEB;
  height:60px;
  font-size: 150%;
}

tr:nth-child(even) {
  background-color: #F0F8FF;
}

tr:nth-child(odd) {
  background-color: #dddddd;
}

tr:hover {background-color: #87CEEB;}
</style>

</head>
<body>
  



<div class="container">
  <h1>Student Information</h1>
  <table>
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Address</th>
    <th>Phone</th>
    <th>Email</th>
  </tr>

  <?php
$sql="SELECT *
from student";
$result = mysqli_query($conn, $sql);
//
while ($row = mysqli_fetch_array ($result))
{
  //$num=$num+1;
  //echo $row;
?>

<tr>
    <td><?php echo $row["stu_id"] ?></td>
    <td><?php echo $row["stu_name"] ?> </td>
    <td><?php echo $row["stu_add"] ?></td>
    <td><?php echo $row["stu_tel"] ?></td>
    <td><?php echo $row["stu_email"] ?></td>
  </tr>
<?php
}
?>
 
  
</table>
</div>

<div class="div5"><input type="button" name="Submit" class="button3" value="Back" onclick="javascript:history.back(1)" /></div>

<?php
  mysqli_close($conn);
  ?>

</body>
</html>