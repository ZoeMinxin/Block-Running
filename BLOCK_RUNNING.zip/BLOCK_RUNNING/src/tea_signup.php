<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('connect.php');
$conn = OpenCon();

$tea_id = $_POST['tea_id'];
$tea_name = $_POST['tea_name'];
$tea_password = $_POST['tea_password'];
$tea_add =$_POST['tea_add'];
$tea_tel = $_POST['tea_tel'];
$tea_email = $_POST['tea_email'];

$exist="select tea_id from teacher where tea_id='$tea_id'";
$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if($erow)
{
    echo "Your ID has been signed up, you'd better change another ID";
    echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/student-login.html';},2000);
        </script>
        ";
}
else
{
    $qu = "INSERT INTO teacher VALUES ('$tea_id', '$tea_name','$tea_password','$tea_add', '$tea_tel', '$tea_email')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        die ('Error: ' . mysqli_error());
        echo "
        <script>
            setTimeout(function(){window.location.href='/it_project/teacher-login.html';},2000);
        </script>
        ";
    
    }
    else{
        echo "Sign up successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='/it_project/teacher-login.html';},2000);
            </script>
            ";
    
    
    }
}






mysqli_close($conn);


?>