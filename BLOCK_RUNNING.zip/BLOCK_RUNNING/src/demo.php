
<?php
session_start();
$name = $_SESSION["stu_name"];
$stu_id=$_SESSION["stu_id"];
include ('connect.php');
$conn = OpenCon();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Welcome to Block Running</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <!--<link href='http://fonts.googleapis.com/css?family=Merienda+One' rel='stylesheet' type='text/css'>-->
  <link rel="stylesheet" href="/it_project/styles.css">
  

</head>
<body>

<nav class="navbar-inverse nav1">
  <div class="container-fluid">
    <div class="navbar-header">

      <?php
      // getting the score of each student 
      $avgscore='0';
      $findcore=" select * from review where stu_id='$stu_id'";
      $scoreresult = mysqli_query ($conn, $findcore);
      while ($rowscore = mysqli_fetch_assoc ($scoreresult))
      {
          if($rowscore["grade_level"])
          {
            $avgscore =$rowscore["grade_level"];  ////store the average score of student log in 
          }
          
      }
      echo "<p style='font-size:2em;text-align:center; padding: 20px 15px'>Hi $name, your total average score is $avgscore</p>";
      ?>

    </div>

    <!-- get student feedback from database -->
    <?php
   
    $sqlsfb="select stu_feedback from feedback where grade_level='$avgscore'";
    $resultsfb = mysqli_query ($conn, $sqlsfb);
    while ($rowsfb = mysqli_fetch_array ($resultsfb))
    {
      $sfb=$rowsfb['stu_feedback'];
    }
    ?>

    <ul class="nav navbar-nav navbar-right">  
      
      <li><a href="rank.php"><button type="button" class="button1 button12">RANK</button></a></li>
      <li><a href="#"><button type="button" class="button1 button13" id="myFeedbackBtn">FEEDBACK</button></a></li>
      <li><a href="/it_project/student-login.html"><button type="button" class="button1 button14">LOGOUT</button></a></li>
<!-- feedback js -->
      <div id="myFeedbackModal" class="modal">
          <div class="modal-content">
            <span class="feedback_close">&times;</span>
            <?php echo "<p style='font-size:2em' >$sfb</p> "; ?>    <!-- FEEDBACK from database -->      
          </div>
        </div>
        <script>
          var feedback_modal = document.getElementById('myFeedbackModal');
    
          var feedback_btn = document.getElementById("myFeedbackBtn");
    
          var feedback_span = document.getElementsByClassName("feedback_close")[0];
    
          feedback_btn.onclick = function() {
            feedback_modal.style.display = "block";
          }
    
          feedback_span.onclick = function() {
            feedback_modal.style.display = "none";
          }
        </script>
    
    
    </ul>
  </div>
</nav>
  
<div class="container">
<p class="p p2">WELCOME <br> BLOCK RUNNING</p><br/>
  
  <ul class="ul1">
    <li><a href="module1.php"><button type="button" class="button2"><div class="div1">MODULE&nbsp;1</div><div class="div2">LINE</div></button></a></li>
    <li><a href="module2.php"><button type="button" class="button2"><div class="div1">MODULE&nbsp;2</div><div class="div2">CIRCLE</div></button></a></li>
    <li><a href="module3.php"><button type="button" class="button2"><div class="div1">MODULE&nbsp;3</div><div class="div2">SNAKE</div></button></a></li>
    <li><a href="module4.php"><button type="button" class="button2"><div class="div1">MODULE&nbsp;4</div><div class="div2">COMPREHENSIVE</div></button></a></li>
  </ul>
  <div>
    <div class="div3"><a href="HowToPlay.php"><button type="button" class="button3">HOW TO PLAY</button></a></div>
    <div class="div4"><a href="HowToScore.php"><button type="button" class="button3">HOW TO SCORE</button></a></div>
  </div>
</div>

</body>
</html>