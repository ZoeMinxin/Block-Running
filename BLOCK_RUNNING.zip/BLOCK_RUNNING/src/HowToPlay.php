
<?php
session_start();
$name = $_SESSION["stu_name"];
$stu_id=$_SESSION["stu_id"];
include ('connect.php');
$conn = OpenCon();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>How to play Block Running</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="/it_project/styles.css">
</head>
<body>

<nav class="navbar-inverse nav1">
  <div class="container-fluid">
    <div class="navbar-header">

    <?php
    // getting the score of each student 
    $avgscore='0';
    $findcore=" select * from review where stu_id='$stu_id'";
    $scoreresult = mysqli_query ($conn, $findcore);
    while ($rowscore = mysqli_fetch_assoc ($scoreresult))
    {
        if($rowscore["grade_level"])
        {
          $avgscore =$rowscore["grade_level"];  ////store the average score of student log in 
        }
        
    }
      echo "<p style='font-size:2em;text-align:center; padding: 20px 15px'>Hi $name, your total average score is $avgscore</p>";
      ?>
      
    </div>
    <!-- get student feedback from database -->
    <?php

    $sqlsfb="select stu_feedback from feedback where grade_level='$avgscore'";
    $resultsfb = mysqli_query ($conn, $sqlsfb);
    while ($rowsfb = mysqli_fetch_array ($resultsfb))
    {
      $sfb=$rowsfb['stu_feedback'];
    }
    ?>

    <ul class="nav navbar-nav navbar-right">  
      
      <li><a href="rank.php"><button type="button" class="button1 button12">RANK</button></a></li>
      <li><a href="#"><button type="button" class="button1 button13" id="myFeedbackBtn">FEEDBACK</button></a></li>
<!-- feedback js -->
      <div id="myFeedbackModal" class="modal">
          <div class="modal-content">
            <span class="feedback_close">&times;</span>
            <?php echo "<p style='font-size:2em' >$sfb</p> "; ?>    <!-- FEEDBACK from database -->      
          </div>
        </div>
        <script>
          var feedback_modal = document.getElementById('myFeedbackModal');
    
          var feedback_btn = document.getElementById("myFeedbackBtn");
    
          var feedback_span = document.getElementsByClassName("feedback_close")[0];
    
          feedback_btn.onclick = function() {
            feedback_modal.style.display = "block";
          }
    
          feedback_span.onclick = function() {
            feedback_modal.style.display = "none";
          }
        </script>

    </ul>
  </div>
</nav>
  
<div class="container">
  <p class="p p2" style="font-size: 70px">BLOCK RUNNING</p><br/>
    <div>
        <div class="div8">
            <img id="arrowImg" src="/it_project/image/arrow.png" alt="arrowImg" class="img2"/>
            <p class="p5"><b>Step1:</b> Choose the <b>MODULE</b></p>
        </div>
        <ul class="ul2">
            <li>MODULE 1 LINE: The shape of the pattern is a LINE.</li>
            <li>MODULE 2 CIRCLE: The shape of the pattern likes a circle.</li>
            <li>MODULE 3 SNAKE: The shape of the pattern is tortuous just like a snake.</li>
            <li>MODULE 4 COMPREHENSIVE: The shape of the pattern is more complex.</li>
        </ul>            
        <p class="p6"><b>DO NOT</b> play in a hurry! We recommend that you play <b>STEP BY STEP</b>!</p>
    </div>
    <div>
        <div class="div8">
            <img id="arrowImg" src="/it_project/image/arrow.png" alt="arrowImg" class="img2"/>
            <p class="p5"><b>Step2:</b> Choose the <b>LEVEL</b></p>
        </div>
        <ul class="ul2">
            <li>There are 2 levels in module 1</li>
            <li>There are 3 levels in module 2</li>
            <li>There are 5 levels in module 3</li>
            <li>There are 10 levels in module 4</li>
        </ul>
        <p class="p6">Remember to play <b>STEP BY STEP</b>~</p>
    </div>
    <div>
        <div class="div8">
            <img id="arrowImg" src="/it_project/image/arrow.png" alt="arrowImg" class="img2"/>
            <p class="p5"><b>Step3:</b> Connect <b>ALL</b> the blocks together without repetition</p>
        </div>
        <p class="p6"><b>We suggest you do not refresh the page frequently!!!</b></p>
    </div>
    <div class="div5"><a href="demo.php"><button type="button" class="button3">BACK</button></a></div>
</div>


</body>
</html>