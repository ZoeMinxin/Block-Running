<?php
session_start();
$name = $_SESSION["stu_name"];
$avgscore = $_SESSION["avg_score"];
$stu_id=$_SESSION["stu_id"];
$gamelevel ="4-5";
include ('connect.php');
$conn = OpenCon();


$avgScore=$_POST['avgScore'];

//echo "$avgScore";
//echo gettype($avgScore);
$stuascore=(int)$avgScore;
//echo "$stuascore";
//echo gettype($stuascore);
if ($stu_id && $gamelevel)
{
    $checkname= "select * from play where stu_id ='$stu_id' and game_level ='$gamelevel'";
    $checkre = mysqli_query($conn, $checkname);
    $checkrow=mysqli_num_rows($checkre);
    if ($checkrow)
    {
        $quexist="update play set score ='$stuascore' where stu_id ='$stu_id' and game_level ='$gamelevel'";
        $resultexist= mysqli_query($conn, $quexist);

    }
    else
    {
        $qu="INSERT INTO play VALUES ('$stu_id', '$gamelevel','$stuascore')";
        $result = mysqli_query($conn, $qu);

    }
}



mysqli_close($conn);
?>